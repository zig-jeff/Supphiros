# Supphiros

![unknown-14](https://github.com/zig-jeff/Supphiros/blob/main/Preview1.png)


It's Cheat MOD for V7. Works on Erekir as well.

에르키르에서도 사용할수 있는 치트 모드입니다.



cheat blocks from super-cheat by Evo04Taser.

some turret and Units from Sapphirium by Snake.

some blocks and Units from many other MOD.

edit Code, draw sprites and add ideas by Jeff.



test play YouTube link https://youtu.be/wJojDcMEd2E

long range cruise missile YouTube link https://youtu.be/lk8CTKI4QYs

drone attack YouTube link https://youtu.be/EcVNcsPUUks

multiple-warhead missile YouTube link https://youtube.com/shorts/EOh8CuOVqv0

## cheat blocks.
CoreBlock: size 3, 4, 5, 6.
 피라미드 모양의 코어블록.

CoreUnit: very fast, long-range build and mining. Repair Unit.
 원거리에서 빠르게 건설, 채굴. 주변 유닛을 수리.

ItemSource, LiquidSource, PowerSource: infinitely outputs.
 자원, 액체, 전력을 무한 공급.

Super Shield: wide range super shield.
 넓은 범위의 튼튼한 방어막.

Super Overdrive: increases the speed of wide range blocks.
 주변 건물들의 스피드 업.

Super Radar, Light Radar: wide range radius.
 넓은 범위의 레이더.

Super Wall: strong barrier. electrical shock to a close enemy.
 튼튼한 방어벽. 근접하는 적에게 전기 충격.

## cheat Turrets.
Basilisk: strong machine-gun turret.
 튼튼한 기관총 포탑.

glow: direct plasma turret.
 직격 플라즈마 포탑.

lighttest: intense electric shock generator.
 강렬한 전기 충격 발생기.

pantagruel: fast mid-range guided missile launcher.
 빠른 중거리 유도미사일 발사대.

qdevastator: long-range cruise missile launcher.
 장거리 크루즈 미사일 발사대.


## cheat Units.
btrxblue: aircraft, such as a core unit.
 코어 유닛과 같은 기체.

btrxtrsp: transparent aircraft for screen capture.
 스크린 캡처를 위한 투명 비행체.

bird: just a bird with no weapons.
 아무런 기능도 없는 그냥 새.

zxkill: destroy nearby our units.
 근처의 아군 유닛을 파괴.

charvon: automatic mining. But not working in Erekir
 자동 채굴. 하지만 에르키르에선 파업.

crepair: automatically rebuilds destroyed blocks.
 파괴된 건물을 자동 복구.

cwisp: Automatic repair, following a nearby fighter.
 가까운 전투기를 따라다니며 자동 수리.

ddagger: high speed machine gun fighter
 고속 기관총 발사 전투기.

ekite: charge fighter with missiles, heavy bullet, and electric shocks.
 미사일, 충격탄, 전기충격을 장착한 돌격 전투기.

fstealth: long-range multi-warhead missile fighter.
 장거리 다탄두 미사일 전투기.

tankus: heavy bullet-mounted insect that launch drones.
 드론 발사대와 중량탄을 장착한 인섹트.

zstarkai: drone launch, omnidirectional laser, energy field, unit repair.
 드론 발사, 전방위 레이져, 에너지 필드, 유닛 수리.

## Screenshots
![unknown-15](https://github.com/zig-jeff/Supphiros/blob/main/Preview2.png)
